package kg.mega.library.enums;

public enum TicketStatus {
    OPEN,
    CLOSED,
    EXPIRED,
    LOST
}
