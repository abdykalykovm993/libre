package kg.mega.library.models.dto;

public record AuthorDto(Long authorId, String name) {
}
