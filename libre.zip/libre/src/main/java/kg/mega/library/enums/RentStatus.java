package kg.mega.library.enums;

public enum RentStatus {
    OPEN,
    CLOSED
}
